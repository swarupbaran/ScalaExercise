package tryouts

/**
  * Created by Swarupsingh on 6/16/2016.
  */
object factorial {

  def main(args: Array[String]) {

    print(factorial(5))

  }

  def factorial(number: BigInt): BigInt =
  {
    if(number < 0)
      1
    else
      number * factorial(number - 1)
  }

}
